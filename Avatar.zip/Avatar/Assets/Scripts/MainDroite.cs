﻿using UnityEngine;
using System.Collections;

public class MainDroite : MonoBehaviour {

    public float initPosX;
    public float initPosY;
    public float initPosZ;

    // Use this for initialization
    void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        
        float xPos = transform.position.x + Input.GetAxis("Horizontal");
        float yPos = transform.position.y + Input.GetAxis("Vertical");
        float zPos = transform.position.z;
        Vector3 pointPos = new Vector3(xPos, yPos, zPos);
        transform.position = pointPos;

    }
}
