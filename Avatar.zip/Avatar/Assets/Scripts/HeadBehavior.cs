﻿using UnityEngine;
using System.Collections;

public class HeadBehavior : MonoBehaviour {

    public float initPosX, initPosY, initPosZ;

	// Use this for initialization
	void Start () {
	
	}
    
	
	// Update is called once per frame
	void Update () {
        if (Input.GetButton("Forward"))
        {
            float zPos = transform.position.z + 0.1f;
            Vector3 pos = new Vector3(transform.position.x, initPosY, zPos);
            transform.position = pos;

        }
        if (Input.GetButton("Backward"))
        {
            float zPos = transform.position.z - 0.1f;
            Vector3 pos = new Vector3(transform.position.x, initPosY, zPos);
            transform.position = pos;

        }
        if (Input.GetButton("Left"))
        {
            float xPos = transform.position.x - 0.1f;
            Vector3 pos = new Vector3(xPos, initPosY, transform.position.z);
            transform.position = pos;

        }
        if (Input.GetButton("Right"))
        {
            float xPos = transform.position.x + 0.1f;
            Vector3 pos = new Vector3(xPos, initPosY, transform.position.z);
            transform.position = pos;

        }
    }
}
